# NOTES-style (branch rewind/style)

Changed, all inside the files the style task owns:
- `web/css/style.css`: new design variables in `:root`, three local fonts, and a "Rewind theme" block near the end. No selector was renamed or removed.
- `web/favicon.svg`: the rewind arrows drawn as pen strokes.
- `web/vendor/fonts/`: added Syne, Familjen Grotesk and Fraunces Italic (.woff2, OFL). The Inter and Instrument Serif files are no longer referenced.

Not touched: any HTML, anything in `web/js/`.

Checked in mock mode at 1280x720 and 390x844: home, name popup, loading, answer, quiz, not covered, lecturer with demo data, QR page. No sideways scroll on the phone size.

Things in other people's files that would finish the look (not done here):
- `web/js/lecturer.js` hardcodes graph colours and `"Inter, sans-serif"` (lines 188-205). Suggested: font face `Familjen Grotesk`, concept boxes `#DDE1F3`, edges `#C9CEE6`.
- The fail-rate bars get an inline green/orange/red colour from JS. In this palette they could be blue up to the threshold and `#D00B1C` above it.
- `web/qr.html` sets the QR colour to `#15172b` in script. `#2E3F93` would match.
- New features: use `var(--accent)`, `var(--mark)`, `var(--display)` and avoid border-radius and box-shadow, the theme block removes both globally.
